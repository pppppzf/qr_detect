^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package image_transport_plugins
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

3.2.0 (2023-05-08)
------------------

3.0.0 (2023-04-18)
------------------
* Update maintainer (`#112 <https://github.com/ros-perception/image_transport_plugins/issues/112>`_)
* Contributors: Kenji Brameld, Michael Carroll

2.6.0 (2022-08-16)
------------------

2.5.0 (2022-04-18)
------------------

2.3.2 (2022-02-18)
------------------

2.3.1 (2021-07-13)
------------------

2.3.0 (2020-05-28)
------------------

2.2.1 (2019-10-23)
------------------

2.2.0 (2019-09-27)
------------------

2.1.0 (2019-08-23)
------------------

2.0.0 (2018-12-13)
------------------
* [ros2] image_transport_plugins 'meta'package. (`#30 <https://github.com/ros-perception/image_transport_plugins/issues/30>`_)
* Update compressed_image_transport to ros2 (`#26 <https://github.com/ros-perception/image_transport_plugins/issues/26>`_)
* Contributors: Michael Carroll, Jose Luis Rivero

1.9.5 (2016-10-03)
------------------

1.9.4 (2016-10-02)
------------------

1.9.3 (2016-01-17)
------------------

1.9.2 (2015-04-25)
------------------

1.9.1 (2014-07-18)
------------------

1.9.0 (2014-05-16)
------------------

1.8.21 (2013-06-27)
-------------------
* maintainer: david gossow
* buildtool_depend catkin, added metapackage CMakelists.txt
* Contributors: David Gossow

1.8.20 (2013-03-18)
-------------------
* 1.8.19 -> 1.8.20
* Contributors: Julius Kammerl

1.8.19 (2013-02-24)
-------------------
* 1.8.18 -> 1.8.19
* removing build dependencies from meta package
* Contributors: Julius Kammerl

1.8.18 (2013-02-07 17:59)
-------------------------
* 1.8.17 -> 1.8.18
* Contributors: Julius Kammerl

1.8.17 (2013-01-18)
-------------------
* 1.8.16 -> 1.8.17
* Contributors: Julius Kammerl

1.8.16 (2013-01-17)
-------------------
* 1.8.15 -> 1.8.16
* removing build_tool dependency from meta package
* Contributors: Julius Kammerl

1.8.15 (2012-12-28 20:11)
-------------------------

1.8.14 (2012-12-28 20:02)
-------------------------

1.8.13 (2012-12-28 19:06)
-------------------------

1.8.12 (2012-12-19 19:30)
-------------------------

1.8.11 (2012-12-19 17:17)
-------------------------

1.8.10 (2012-12-19 17:03)
-------------------------

1.8.9 (2012-12-19 00:26)
------------------------
* switching to verion 1.8.9
* Contributors: Julius Kammerl

1.8.8 (2012-12-17)
------------------
* adding build_deb on message_generation & mrun_deb on message_runtime
* Updated package.xml for new buildtool_depend tag for catkin requirement
* Contributors: Julius Kammerl, mirzashah

1.8.7 (2012-12-10 15:29)
------------------------
* adding missing tf build dependency
* Contributors: Julius Kammerl

1.8.6 (2012-12-10 15:08)
------------------------
* switching to version 1.8.6
* Contributors: Julius Kammerl

1.8.5 (2012-12-09)
------------------
* more meta package fixing.. adding build debs
* fixing meta package
* fixed meta package
* switching to 1.8.5
* Contributors: Julius Kammerl

1.8.4 (2012-11-30)
------------------
* switching to version 1.8.4
* adding image_transport_plugins meta package
* Contributors: Julius Kammerl
